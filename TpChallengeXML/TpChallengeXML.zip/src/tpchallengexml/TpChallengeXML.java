
package tpchallengexml;
import java.io.*;
import java.util.ArrayList;
import org.xml.sax.*;
import org.xml.sax.helpers.*;
import modele.Coureurs;
import modele.Gestionnaire;
import modele.Courses;


public class TpChallengeXML {

    public static void main(String[] args) {
 try
        {
            Class c = Class.forName("org.apache.xerces.parsers.SAXParser");
            XMLReader parser = (XMLReader) c.newInstance();
            // ici, à titre d'exemple, la classe Java effectuant le parsing (l'analyse)
            // s'appelle Gestionnaire.java
            Gestionnaire gestioner= new Gestionnaire();
            parser.setContentHandler(gestioner);
            parser.parse("./src/javaxmltest/ressources/resultatsressources.xml");
            ArrayList<Coureurs> lesCoureurs = gestioner.retour();
            System.out.println("LE GAGANT DE LA COURSE EST " + lesCoureurs.get(0).getNom());
            
            System.out.println("CLASSEMENT");
            
            for (int i=0; i<lesCoureurs.size(); i++)
            {
                System.out.println(lesCoureurs.get(i).getPlace() + " - " + lesCoureurs.get(i).getNom() + " - " + lesCoureurs.get(i).getPrenom());
            }
        }
        catch(Exception e)
        {
            System.out.println(e);
        }
    }
    
}
