
package modele;

import modele.Coureurs;
import modele.Courses;
import org.xml.sax.*;
import org.xml.sax.helpers.*;
import java.sql.*;
import java.util.ArrayList;

public class Gestionnaire extends DefaultHandler
{
    ArrayList lesCoureurs;
    ArrayList lesCourses;
    Coureurs MonCoureur;
    Courses MaCourse;
    String baliseCourante;
    
    @Override
    public void startDocument() throws SAXException {
      lesCoureurs = new ArrayList<Coureurs>(); 
      lesCourses = new ArrayList<Courses>();
    }

    @Override
    public void endDocument() throws SAXException {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {
        if (qName.equals("coureur"))
        {
            MonCoureur = new Coureurs();
        }
        baliseCourante = qName;
    }

    @Override
    public void endElement(String uri, String localName, String qName) throws SAXException {
        if (qName.equals("coureur"))
        {
            lesCoureurs.add(MonCoureur);
        }
    }

    @Override
    public void characters(char[] ch, int start, int length) throws SAXException
    {
        String donnees = new String(ch, start, length);
        if (!Character.isISOControl(ch[start]))
        {
        
        if (baliseCourante.equals("place"))
        {
            MonCoureur.setPlace(Integer.parseInt(donnees));
        }

        if (baliseCourante.equals("nom"))
        {
            MonCoureur.setNom(donnees);
        }

        if (baliseCourante.equals("prenom"))
        {
            MonCoureur.setPrenom(donnees);
        }
        }
    }
   public ArrayList retour()
   {return lesCoureurs;}
}
